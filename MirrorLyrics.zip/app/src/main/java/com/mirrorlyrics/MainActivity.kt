package com.mirrorlyrics

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.*
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.*
import android.widget.FrameLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : Activity() {
    data class Line(val t: Long, val s: String)

    private lateinit var tv: TextView
    private var lines = listOf<Line>()
    private var key = ""
    private var noLyrics = false
    private var mode = 1          // 0 normal, 1 mirror, 2 flip vertical, 3 both
    private var offset = 0L       // manual sync shift in ms
    private val h = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 1f }
        tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 30f; gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(tv, FrameLayout.LayoutParams(-1, -1))
            setOnTouchListener { v, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    when {
                        !listenerEnabled() -> startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                        e.x < v.width * 0.25f -> offset -= 250   // lyrics came too early/late: nudge
                        e.x > v.width * 0.75f -> offset += 250
                        else -> { mode = (mode + 1) % 4; applyMode() }
                    }
                }
                true
            }
        }
        setContentView(root)
        applyMode()
    }

    private fun applyMode() {
        tv.scaleX = if (mode == 1 || mode == 3) -1f else 1f
        tv.scaleY = if (mode == 2 || mode == 3) -1f else 1f
    }

    private val tick = object : Runnable { override fun run() { update(); h.postDelayed(this, 80) } }
    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun listenerEnabled() =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true

    private fun update() {
        if (!listenerEnabled()) { tv.text = "Tap screen, then enable\nMirror Lyrics\nin Notification access"; return }
        val msm = getSystemService(MediaSessionManager::class.java)
        val cs = try { msm.getActiveSessions(ComponentName(this, NLS::class.java)) } catch (e: Exception) { emptyList() }
        val c = cs.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: cs.firstOrNull()
        if (c == null) { tv.text = "Play a song…"; return }
        val m = c.metadata ?: return
        val title = m.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION) / 1000
        val k = "$artist|$title"
        if (k != key) { key = k; lines = emptyList(); noLyrics = false; offset = 0; fetch(artist, title, dur, k) }
        val st = c.playbackState ?: return
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING)
            pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
        render(pos + offset)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(u: String): String? = try {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "MirrorLyrics/1.0")
        if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }

    private fun fetch(a: String, t: String, d: Long, k: String) {
        Thread {
            var res = emptyList<Line>()
            try {
                var s = get("https://lrclib.net/api/get?track_name=${enc(t)}&artist_name=${enc(a)}&duration=$d")
                    ?.let { JSONObject(it).optString("syncedLyrics", "") } ?: ""
                if (s.isBlank()) {
                    val clean = t.replace(Regex("\\(.*?\\)|\\[.*?\\]"), "").trim()
                    val arr = get("https://lrclib.net/api/search?q=${enc("$a $clean")}")?.let { JSONArray(it) }
                    if (arr != null) for (i in 0 until arr.length()) {
                        val x = arr.getJSONObject(i).optString("syncedLyrics", "")
                        if (x.isNotBlank()) { s = x; break }
                    }
                }
                res = parse(s)
            } catch (e: Exception) { }
            h.post { if (k == key) { lines = res; noLyrics = res.isEmpty() } }
        }.start()
    }

    private fun parse(s: String): List<Line> {
        val r = Regex("\\[(\\d+):(\\d+(?:\\.\\d+)?)]")
        val out = ArrayList<Line>()
        for (l in s.lines()) {
            val ms = r.findAll(l).toList()
            if (ms.isEmpty()) continue
            val text = l.substring(ms.last().range.last + 1).trim()
            for (m in ms) out.add(Line(((m.groupValues[1].toLong() * 60 + m.groupValues[2].toDouble()) * 1000).toLong(), text))
        }
        return out.sortedBy { it.t }
    }

    private fun render(pos: Long) {
        if (lines.isEmpty()) { tv.text = if (noLyrics) "No synced lyrics found" else "Searching lyrics…"; return }
        val i = lines.indexOfLast { it.t <= pos }
        val sb = SpannableStringBuilder()
        fun add(s: String, c: Int, size: Float = 1f) {
            val st = sb.length
            sb.append(s).append("\n\n")
            sb.setSpan(ForegroundColorSpan(c), st, st + s.length, 0)
            sb.setSpan(RelativeSizeSpan(size), st, st + s.length, 0)
        }
        val dim = 0xFF666666.toInt()
        add(lines.getOrNull(i - 1)?.s ?: "", dim)
        val cur = lines.getOrNull(i)
        if (cur == null || cur.s.isBlank()) add("♪", Color.WHITE, 1.3f)
        else {
            // Word-by-word: spread the words across the time until the next line.
            val gap = ((lines.getOrNull(i + 1)?.t ?: (cur.t + 4000)) - cur.t).coerceIn(1, 6000)
            val f = ((pos - cur.t).toFloat() / (gap * 0.85f)).coerceIn(0f, 1f)
            val w = cur.s.split(" ")
            val lit = Math.ceil((f * w.size).toDouble()).toInt().coerceAtMost(w.size)
            val n = w.take(lit).joinToString(" ").length
            val st = sb.length
            sb.append(cur.s).append("\n\n")
            sb.setSpan(ForegroundColorSpan(Color.WHITE), st, st + n, 0)
            sb.setSpan(ForegroundColorSpan(0xFF8899AA.toInt()), st + n, st + cur.s.length, 0)
            sb.setSpan(RelativeSizeSpan(1.3f), st, st + cur.s.length, 0)
        }
        add(lines.getOrNull(i + 1)?.s ?: "", dim)
        tv.text = sb
    }
}
