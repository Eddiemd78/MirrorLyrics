package com.mirrorlyrics

import android.service.notification.NotificationListenerService

// Needed only so Android lets us read media sessions of any player.
class NLS : NotificationListenerService()
